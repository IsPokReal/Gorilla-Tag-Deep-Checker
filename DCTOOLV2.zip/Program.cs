﻿using System.Runtime.CompilerServices;
using System;
using System.Xml.Linq;
using System.Net;
using System.Diagnostics;

class GFG
{
    

    public static async Task Main(string[] args)
    {
        


        Console.ForegroundColor = ConsoleColor.Red;
        Console.Title = "Deep Checker & Passer";

        Console.WriteLine("\t\t\t|  __ \\ / __ \\| |/ /\r\n\t\t\t| |__) | |  | | ' / \r\n\t\t\t|  ___/| |  | |  <  \r\n\t\t\t| |    | |__| | . \\ \r\n\t\t\t|_|     \\____/|_|\\_\\");

        Console.WriteLine("\n\nINFO -  Deep Checker, Checks all of the files inside plugins & downloads a file(.dll) used for ingame checks\n\tDeep Check Bypass, Create a new folder named whatever it HAS to be in the same directory\n\tSearch Downloads For Cheats, Searches through their download folder to see each cheat/mod they've downloaded and displays it!\n\tCheck Override World Scale, Checks, Opens & Displays the players | Override World Scale, Predictions, Frames, and Resolution.");
        Console.WriteLine("\n\n1 | Deep Checker\n2 | Deep Check Bypass\n3 | Search Downloads For Cheats\n4 | Check Override World Scale (STEAM VR)");


        string GetInput;
        string PathToplugins;
        GetInput = Console.ReadLine();
        if (GetInput == "1")
        {
            WebClient WC = new WebClient();
            Uri newURI = new Uri("https://cdn.discordapp.com/attachments/1121280254120575026/1247304512910131220/DeepCheckerbyPOK.dll?ex=666abf19&is=66696d99&hm=a42a4f9ea860a8262c938409ada582f68a215a21870f16e60fadf7f7e7ce607a&");
            WC.DownloadFileAsync(newURI, "DeepCheckerPOK.dll");

            Console.WriteLine("Please Add Path To Plugin Folder\n");
            PathToplugins = Console.ReadLine();
            if (PathToplugins == null)
            {
                Console.WriteLine("NULL\n");
            }
            else
            {
                string[] EachFiles = Directory.GetFiles(PathToplugins);
                string[] EachDirectories = Directory.GetDirectories(PathToplugins);
                Console.WriteLine("\n");
                foreach (string EachFile in EachFiles)
                {
                    Console.WriteLine($"FILE | {EachFile}\n");
                }
                foreach (string EachDirectory in EachDirectories)
                {
                    Console.WriteLine($"FOLDER | {EachDirectory}\n");
                }
            }
            Console.ReadKey();
            return;
        }


        else if (GetInput == "2")
        {
            Console.Clear();
            Console.WriteLine("Please Add Path To Folder\n");

            string PathToFolder;
            string PathToNewFile;
            PathToFolder = Console.ReadLine();
            Console.WriteLine("Please Add Path To Cheat Folder\n");
            PathToNewFile = Console.ReadLine();
            if (PathToFolder == null && PathToNewFile == null)
            {
                Console.WriteLine("NULL\n");
                return;
            }
            else
            {
                if (Directory.Exists(PathToFolder))
                {
                    string[] AllFilesInDirectory = Directory.GetFiles(PathToFolder);
                    foreach (string AllFiles in AllFilesInDirectory)
                    {
                        if (AllFiles.Contains("Assembly-CSharp"))
                        {
                            DateTime dateTime = File.GetCreationTime(AllFiles);
                            File.Delete(AllFiles);
                            File.Copy(PathToNewFile, AllFiles);
                            File.SetCreationTime(AllFiles, dateTime);
                            File.SetLastAccessTime(AllFiles, dateTime);
                        }
                        else
                        {
                            Console.WriteLine("File, {Assembly-CSharp} is missing\n");
                        }
                    }
                }
                Console.ReadKey();
                return;
            }
            
        }



        else if (GetInput == "3")
        {
            string username = Environment.UserName;
            string pathToDownloads = Path.Combine("C:\\Users", username, "Downloads");

            try
            {
                string[] allFilesInDownloadsArray = Directory.GetFiles(pathToDownloads);
                string[] allDirectoryInDownloadsArray = Directory.GetDirectories(pathToDownloads);
                foreach (string file in allFilesInDownloadsArray)
                {
                    if (file.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                    {
                        Console.WriteLine($"{file}\n");
                    }
                }
                foreach (string directory in allDirectoryInDownloadsArray)
                {
                    string DirectoryPath = Path.Combine(directory);
                    string[] FilesInDirectory = Directory.GetFiles(DirectoryPath);
                    foreach (string fil in FilesInDirectory)
                    {
                        if (fil.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                        {
                            Console.WriteLine($"{fil}\n");
                        }
                    }
                    string[] DirectoryInDirectory = Directory.GetDirectories(DirectoryPath);
                    foreach(string did in DirectoryInDirectory)
                    {
                        string[] augh = Directory.GetFiles(did);
                        foreach (string filesss in augh)
                        {
                            if (filesss.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine($"{filesss}\n");
                            }
                        }
                    }
                }
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            return;
        }



        else if (GetInput == "4")
        {
            string path = @"C:\Program Files (x86)\Steam\config";
            string fileName = "steamvr.vrsettings";
            string filePath = Path.Combine(path, fileName);
            string[] alllines = File.ReadAllLines(filePath);
            string ToFind = "steam.app.1533390";

            try
            {
                if (File.Exists(filePath))
                {
                    Process.Start("notepad.exe", filePath);
                    for (int i = 0; i < alllines.Length; i++)
                    {
                        if (alllines[i].Contains(ToFind))
                        {
                            Console.WriteLine($" NORMAL SHOULD LOOK LIKE THIS \n\t(additionalFramesToPredict : 0\n\tframesToThrottle : WHATEVER NORMAL HZ IS\n\tmotionSmoothingOverride : 1\n\tresolutionScale : 100\n\tworldScale : 1 |\n'{ToFind}'|\n");

                            for (int j = i + 1; j < Math.Min(i + 6, alllines.Length); j++)
                            {
                                Console.WriteLine($"{alllines[j]}\n");
                            }
                            break; 
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"File {fileName} not found in {path}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }



        else
        {
            Console.WriteLine("Pick An Answer");
            return;
        }
        Console.ReadKey();
    }

    
    
}
